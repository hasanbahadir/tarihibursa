
  # Bursa Tarihi Turizm Rehberi Websitesi

  This is a code bundle for Bursa Tarihi Turizm Rehberi Websitesi. The original project is available at https://www.figma.com/design/ddvwmsRZDzt8jMZpE6B36J/Bursa-Tarihi-Turizm-Rehberi-Websitesi.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  